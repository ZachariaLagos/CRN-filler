// NU CRN Filler content script.
//
// Manual mode: fills CRNs when you click "Fill page now."
// Scheduled mode: at your registration time, submits your main CRNs. A CRN
// that fails is retried up to MAX_ATTEMPTS times total; after that, the next
// backup CRN takes its place (with the same limit).
//
// If Banner crashes, shows an error page, or stops responding, the extension
// pauses, alerts you (sound + desktop notification), and saves its progress.
// Reload the page and it resumes where it left off. It never reloads by itself.
//
// SELECTORS and STATUS words match Banner 9's standard registration page.
// Verify them with DevTools (right-click > Inspect) and edit if NU's differs.

// ---------------- Settings ----------------
const SEL = {
  enterCrnsTab: "#enterCRNs-tab, a[href='#enterCRNs']",
  crnInput: (n) => `#txt_crn${n}`,
  allCrnInputs: "input[id^='txt_crn']",
  addAnotherBtn: "#addAnotherCRN",
  addToSummaryBtn: "#addCRNbutton",
  submitBtn: "#saveButton",
  summaryRows: "#summaryBody tr, #summary tr, [id*='summary' i] tr, [id*='summary' i] [role='row']",
};

const STATUS = {
  failed: [/error/i, /deleted/i, /closed/i, /not registered/i, /full/i],
  ok: [/registered/i, /waitlisted/i],
};

// Text that means Banner itself is broken, not that a course failed.
const PAGE_ERRORS = [
  /service unavailable/i, /bad gateway/i, /gateway time-?out/i, /internal server error/i,
  /\b50[234]\b.*error/i, /an unexpected error/i, /session (has )?(expired|timed out)/i,
  /your session is about to expire/i,
];

const MAX_ATTEMPTS = 3;            // submits per CRN, including the first
const RETRY_DELAY_MS = 5000;       // pause between retry rounds
const GRACE_MS = 10 * 60 * 1000;   // how long to wait for CRN boxes to appear
const RESULT_TIMEOUT_MS = 60000;   // how long to wait for Banner to show results
const STALE_MS = 60 * 60 * 1000;   // give up resuming a run older than this

// ---------------- Helpers ----------------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const TAB_ID = Math.random().toString(36).slice(2);

function waitFor(selector, timeout = 4000) {
  return new Promise((resolve) => {
    const found = document.querySelector(selector);
    if (found) return resolve(found);
    const obs = new MutationObserver(() => {
      const el = document.querySelector(selector);
      if (el) { obs.disconnect(); resolve(el); }
    });
    obs.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => { obs.disconnect(); resolve(null); }, timeout);
  });
}

function setValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
  setter.call(input, value);
  ["input", "change", "keyup", "blur"].forEach((t) => input.dispatchEvent(new Event(t, { bubbles: true })));
}

function pageError() {
  const text = (document.title + " " + (document.body?.innerText || "")).slice(0, 20000);
  const hit = PAGE_ERRORS.find((re) => re.test(text));
  return hit ? text.match(hit)[0] : null;
}

// ---------------- Alerts ----------------
let bannerEl = null;
function showBanner(text, kind = "info") {
  if (!bannerEl) {
    bannerEl = document.createElement("div");
    bannerEl.setAttribute("role", "status");
    Object.assign(bannerEl.style, {
      position: "fixed", top: "0", left: "0", right: "0", zIndex: 2147483647,
      padding: "10px 16px", font: "600 14px/1.4 system-ui, sans-serif", color: "#fff",
      textAlign: "center", boxShadow: "0 2px 6px rgba(0,0,0,.25)",
    });
    document.documentElement.appendChild(bannerEl);
  }
  bannerEl.style.background = kind === "error" ? "#C8102E" : kind === "ok" ? "#1f7a3a" : "#333";
  bannerEl.textContent = "NU CRN Filler: " + text;
}

function beep(times = 3) {
  try {
    const ctx = new AudioContext();
    for (let i = 0; i < times; i++) {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.value = 0.2;
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + i * 0.35);
      o.stop(ctx.currentTime + i * 0.35 + 0.2);
    }
  } catch (_) { /* audio may be blocked; the notification still shows */ }
}

function alertUser(message, { urgent = true, kind = "error" } = {}) {
  showBanner(message, kind);
  if (urgent) beep();
  chrome.runtime.sendMessage({
    type: "ALERT", urgent,
    title: urgent ? "Registration needs you" : "NU CRN Filler",
    message,
  });
}

// ---------------- Filling and submitting ----------------
async function openCrnTab() {
  const tab = document.querySelector(SEL.enterCrnsTab);
  if (tab && !document.querySelector(SEL.crnInput(1))?.offsetParent) {
    tab.click();
    await sleep(300);
  }
}

async function fillCrns(crns, addToSummary, fieldTimeout = 4000) {
  await openCrnTab();
  const first = await waitFor(SEL.crnInput(1), fieldTimeout);
  if (!first) return { ok: false, message: "Couldn’t find the CRN fields. Open Register for Classes and pick a term." };

  document.querySelectorAll(SEL.allCrnInputs).forEach((el) => setValue(el, ""));

  for (let i = 0; i < crns.length; i++) {
    const n = i + 1;
    let input = document.querySelector(SEL.crnInput(n));
    if (!input) {
      const more = document.querySelector(SEL.addAnotherBtn);
      if (!more) return { ok: false, message: `Filled ${i}, but couldn’t find “Add Another CRN.”` };
      more.click();
      input = await waitFor(SEL.crnInput(n), 5000);
      if (!input) return { ok: false, message: `Filled ${i}, then no new field appeared.` };
    }
    setValue(input, crns[i]);
    await sleep(60);
  }

  if (addToSummary) {
    const btn = document.querySelector(SEL.addToSummaryBtn);
    if (!btn) return { ok: false, message: `Filled ${crns.length}, but couldn’t find “Add to Summary.”` };
    btn.click();
    return { ok: true, message: `Filled ${crns.length} and added them to your summary. Review, then click Submit.` };
  }
  return { ok: true, message: `Filled ${crns.length}. Review, then click Add to Summary and Submit.` };
}

function rowFor(crn) {
  let rows = [...document.querySelectorAll(SEL.summaryRows)];
  if (!rows.length) rows = [...document.querySelectorAll("tr")];
  return rows.filter((r) => r.innerText.includes(crn)).pop() || null;
}

function statusOf(crn) {
  const row = rowFor(crn);
  if (!row) return "unknown";
  const text = row.innerText;
  if (STATUS.failed.some((re) => re.test(text))) return "failed";
  if (STATUS.ok.some((re) => re.test(text))) return "ok";
  return "unknown";
}

async function waitForInSummary(crns, timeout = 20000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    if (pageError()) return false;
    if (crns.every((c) => rowFor(c))) return true;
    await sleep(200);
  }
  return false;
}

async function waitForResults(crns, timeout = RESULT_TIMEOUT_MS) {
  const start = Date.now();
  let results = {};
  while (Date.now() - start < timeout) {
    const err = pageError();
    if (err) return { error: `Banner showed an error (“${err}”).` };
    results = Object.fromEntries(crns.map((c) => [c, statusOf(c)]));
    if (Object.values(results).every((s) => s !== "unknown")) break;
    if (Date.now() - start > 15000) showBanner("Banner is slow. Still waiting for results…");
    await sleep(300);
  }
  return { results };
}

async function submitRound(crns, fieldTimeout) {
  const fill = await fillCrns(crns, true, fieldTimeout);
  if (!fill.ok) return { error: pageError() ? `Banner showed an error (“${pageError()}”).` : fill.message, beforeSubmit: true };
  await waitForInSummary(crns);
  const t = Date.now();
  while (Date.now() - t < 3000 && crns.some((c) => statusOf(c) === "failed")) await sleep(150);
  await sleep(300);
  const submit = await waitFor(SEL.submitBtn, 15000);
  if (!submit) return { error: "Couldn’t find the Submit button.", beforeSubmit: true };
  submit.click();
  await sleep(800);
  return waitForResults(crns);
}

// ---------------- Saved progress ----------------
// schedule = { time, state: "armed" | "firing" | "paused" | "done", message, ok, progress }
// progress = { registered, failed, attempts, queue, toTry, inFlight }

async function getSchedule() {
  return (await chrome.storage.local.get("schedule")).schedule;
}

async function saveProgress(progress, state = "firing", message = "") {
  const s = await getSchedule();
  if (!s) return false; // cancelled from the popup
  await chrome.storage.local.set({ schedule: { ...s, state, message, progress } });
  return true;
}

function finish(ok, message) {
  stopLock();
  return chrome.storage.local.set({ schedule: { state: "done", ok, message, finishedAt: Date.now() } });
}

// Only one Banner tab runs at a time.
let lockTimer = null;
async function takeLock() {
  const { runLock } = await chrome.storage.local.get("runLock");
  if (runLock && runLock.id !== TAB_ID && Date.now() - runLock.at < 6000) return false;
  const beat = () => chrome.storage.local.set({ runLock: { id: TAB_ID, at: Date.now() } });
  await beat();
  lockTimer = setInterval(beat, 2000);
  return true;
}
function stopLock() {
  clearInterval(lockTimer);
  chrome.storage.local.remove("runLock");
}

function summary(p) {
  const parts = [];
  if (p.registered.length) parts.push(`Registered: ${p.registered.join(", ")}.`);
  if (p.failed.length) parts.push(`Failed after ${MAX_ATTEMPTS} tries: ${p.failed.join(", ")}.`);
  return parts.join(" ");
}

// Decide what happens to one CRN after Banner reports on it.
function classify(p, crn, status, next) {
  if (status === "ok") p.registered.push(crn);
  else if ((p.attempts[crn] || 0) < MAX_ATTEMPTS) next.push(crn);
  else { p.failed.push(crn); if (p.queue.length) next.push(p.queue.shift()); }
}

async function pause(p, reason) {
  await saveProgress(p, "paused", `${reason} Reload the registration page and it will pick up where it left off.`);
  stopLock();
  alertUser(`${reason} Reload this page to resume. ${summary(p)}`);
}

// ---------------- Main loop ----------------
let running = false;

async function runEngine(p, fieldTimeout) {
  while (p.toTry.length) {
    if (!(await getSchedule())) { stopLock(); showBanner("Cancelled."); return; }

    p.toTry.forEach((c) => (p.attempts[c] = (p.attempts[c] || 0) + 1));
    p.inFlight = [...p.toTry];
    await saveProgress(p);
    showBanner(`Submitting ${p.toTry.join(", ")}…`);

    const round = await submitRound(p.toTry, fieldTimeout);
    fieldTimeout = 15000;

    if (round.error) {
      if (round.beforeSubmit) {
        // Nothing was submitted this round, so don't count it as an attempt.
        p.toTry.forEach((c) => p.attempts[c]--);
        p.inFlight = [];
      }
      return pause(p, round.error);
    }

    const next = [];
    const unclear = [];
    for (const crn of p.toTry) {
      const s = round.results[crn];
      if (s === "unknown") unclear.push(crn);
      else classify(p, crn, s, next);
    }
    if (unclear.length) {
      // Keep unclear CRNs in flight so a reload re-checks them before doing anything else.
      p.inFlight = unclear;
      p.toTry = next;
      return pause(p, `Banner didn’t confirm ${unclear.join(", ")} within ${RESULT_TIMEOUT_MS / 1000} seconds.`);
    }
    p.inFlight = [];
    p.toTry = next;
    await saveProgress(p);
    if (p.toTry.length) {
      showBanner(`Retrying in ${RETRY_DELAY_MS / 1000} seconds… ${summary(p)}`);
      await sleep(RETRY_DELAY_MS);
    }
  }

  const { crns = [] } = await chrome.storage.local.get("crns");
  const allDone = p.registered.length >= crns.length;
  const msg = summary(p) + (allDone ? "" : " Ran out of tries and backups. Check Banner for the error reasons.");
  await finish(allDone, msg);
  alertUser(msg, { urgent: !allDone, kind: allDone ? "ok" : "error" });
}

async function startFresh() {
  if (running) return;
  const s = await getSchedule();
  const { crns = [], backups = [] } = await chrome.storage.local.get(["crns", "backups"]);
  if (s?.state !== "armed" || !crns.length) return;
  if (!(await takeLock())) return;
  running = true;
  const p = { registered: [], failed: [], attempts: {}, queue: [...backups], toTry: [...crns], inFlight: [] };
  await saveProgress(p);
  await runEngine(p, Math.max(0, s.time + GRACE_MS - Date.now()));
  running = false;
}

async function resume() {
  if (running) return;
  const s = await getSchedule();
  if (!s?.progress || !["firing", "paused"].includes(s.state)) return;
  if (Date.now() - s.time > STALE_MS) {
    return finish(false, `Stopped: the run was interrupted over an hour ago. ${summary(s.progress)} Check Banner.`);
  }
  const err = pageError();
  if (err) return alertUser(`Banner is showing an error (“${err}”). Reload again in a moment to resume.`);
  if (!(await takeLock())) return;
  running = true;
  const p = s.progress;
  showBanner("Resuming. Pick your term if Banner asks, then go to Enter CRNs.");

  // First, find out what happened to anything that was mid-submit when things broke.
  if (p.inFlight.length) {
    await openCrnTab();
    const ready = await waitFor(SEL.crnInput(1), GRACE_MS);
    if (!ready) { running = false; return pause(p, "The registration page didn’t load."); }
    let statuses = {};
    const start = Date.now();
    while (Date.now() - start < 20000) {
      statuses = Object.fromEntries(p.inFlight.map((c) => [c, statusOf(c)]));
      if (Object.values(statuses).every((v) => v !== "unknown")) break;
      await sleep(300);
    }
    const unknown = p.inFlight.filter((c) => statuses[c] === "unknown");
    if (unknown.length) {
      // Can't tell if these went through. Stop rather than risk going over your course limit.
      const msg = `${summary(p)} Couldn’t confirm whether ${unknown.join(", ")} registered. Check Banner and finish by hand.`;
      await finish(false, msg);
      alertUser(msg);
      running = false;
      return;
    }
    const next = [];
    for (const crn of p.inFlight) classify(p, crn, statuses[crn], next);
    p.toTry = [...next, ...p.toTry.filter((c) => !next.includes(c))];
    p.inFlight = [];
    await saveProgress(p);
  }

  await runEngine(p, GRACE_MS);
  running = false;
}

// ---------------- Startup ----------------
let timer = null;
function onSchedule(s) {
  clearTimeout(timer);
  if (!s) { if (bannerEl) showBanner("Cancelled."); return; }
  if (s.state === "armed") {
    const wait = s.time - Date.now();
    if (wait < -GRACE_MS) return finish(false, "The scheduled time passed while the page wasn’t open.");
    showBanner(`Scheduled for ${new Date(s.time).toLocaleTimeString()}. Keep this tab open.`);
    timer = setTimeout(startFresh, Math.max(0, wait));
  }
}

chrome.storage.local.get("schedule", ({ schedule: s }) => {
  if (s && ["firing", "paused"].includes(s.state)) resume();
  else onSchedule(s);
});
chrome.storage.onChanged.addListener((c) => {
  if (c.schedule && c.schedule.newValue?.state !== c.schedule.oldValue?.state) {
    if (c.schedule.newValue?.state === "armed" || !c.schedule.newValue) onSchedule(c.schedule.newValue);
  }
});

// ---------------- Manual fill from the popup ----------------
chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  if (msg?.type !== "FILL_CRNS") return;
  fillCrns(msg.crns, msg.addToSummary).then(sendResponse);
  return true;
});
